/**
 * Copyright (C) 2009  DAINIPPON SCREEN MFG. CO., LTD.  All Rights Reserved.
 *
 * N O T I C E
 * THIS MATERIAL IS CONSIDERED A TRADE SECRET BY DAINIPPON SCREEN.
 * UNAUTHORIZED ACCESS IS PROHIBITED.
 */


package com.gcs.cms.constants;

/**
 * Class Description
 ?���*
 * @author GCS
 * @since EQUIOS 2.03
 */
public class Constants {
    
    public static final String HTML_TAG_BODY = "body";
    
    public static final String UTF8_ENCODING = "UTF-8";
    
    public static final String ATTR_STYLE = "style";
    
    // TUNG NGUYEN - 208/03/14
    public static final String MY_NODE_FREFIX = "gcs-";
    
    public static final String TAG_PATTERN = "\\[([a-zA-Z-]+)([^\\]]*)\\]([^^]*)\\[/\\1\\]";
    public static final int OFFSET_TAG_NAME = 1;
    public static final int OFFSET_TAG_VALUE = 2;
    public static final int OFFSET_TAG_TEXT = 3;
}
