package com.gcs.cms.main;

import com.gcs.cms.reader.IFileReader;
import com.gcs.cms.reader.HTMLFileReader;

/**
 * This plug-in is used to apply CSS tag and Html tag to SPHINX.
 * 
 * @author GCS
 */
public class Main {

    /**
     * Method description
     * 
     * @since EQUIOS 2.03
     */
    public static void main(String[] args) {

        try {
            System.out.println("------------- CSSPlugin--------------");
            
            if (args.length <= 0) {
                throw new Exception("ERROR - Required at least one argument.");
            }

            IFileReader readerHTML = new HTMLFileReader();
            System.out.println(" - Start reading file: " + args[0]);
            readerHTML.readFile(args[0]);
            System.out.println(" - End reading file -");
            System.out.println(" - Start parse file -");
            readerHTML.parseFile();
            System.out.println(" - End parse file -");
            System.out.println(" - Start save file: " + args[0]);
            readerHTML.saveFile(args[0]);
            System.out.println(" - End save file.");

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        System.out.println("-------------------------------------");
    }
}
