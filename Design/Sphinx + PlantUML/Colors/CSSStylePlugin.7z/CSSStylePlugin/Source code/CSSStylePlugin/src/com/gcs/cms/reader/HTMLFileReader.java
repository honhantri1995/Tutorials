/**
 * Copyright (C) 2009  DAINIPPON SCREEN MFG. CO., LTD.  All Rights Reserved.
 *
 * N O T I C E
 * THIS MATERIAL IS CONSIDERED A TRADE SECRET BY DAINIPPON SCREEN.
 * UNAUTHORIZED ACCESS IS PROHIBITED.
 */

package com.gcs.cms.reader;

import java.io.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.nodes.Node;
import org.jsoup.parser.Tag;
import org.jsoup.select.Elements;
import org.jsoup.select.NodeVisitor;

import com.gcs.cms.constants.Constants;
import com.gcs.cms.utils.HtmlUtils;

/**
 * Class Description ﾌ�*
 * 
 * @author GCS
 * @since EQUIOS 2.03
 */
public class HTMLFileReader implements IFileReader {

    final Pattern gcsTagPattern = Pattern.compile(Constants.TAG_PATTERN);

    Document doc;

    /**
     * {@inheritDoc}
     */
    public void readFile(String path) {
        // TODO Auto-generated method stub
        try {
            File file = new File(path);
            doc = Jsoup.parse(file, Constants.UTF8_ENCODING);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * {@inheritDoc}
     */
    public void parseFile() throws Exception {
        Elements bodyElement = doc.getElementsByTag(Constants.HTML_TAG_BODY);
        // Traverse each element.
        bodyElement.traverse(new NodeVisitor() {

            public void head(Node element, int index) {
                Matcher matcher = gcsTagPattern.matcher(element.outerHtml());
                while (matcher.find()) {
                    Element spanHTML;
                    if (matcher.group(Constants.OFFSET_TAG_VALUE).isEmpty()) {
                        // This element has sample format: [div]hello[/div]
                        // This element will be conversed to an HTML tag.
                        spanHTML = HtmlUtils.generateHTMLTag(
                                matcher.group(Constants.OFFSET_TAG_NAME),
                                matcher.group(Constants.OFFSET_TAG_TEXT));
                    } else {
                        // This element has sample format: [color red]hello[/color]
                        // This element will be conversed to an style attribute of SPAN element.
                        spanHTML = HtmlUtils.generateSpanTagWithCSS(
                                matcher.group(Constants.OFFSET_TAG_NAME),
                                matcher.group(Constants.OFFSET_TAG_VALUE),
                                matcher.group(Constants.OFFSET_TAG_TEXT));
                    }
                    String parentHtml = ((Element) element).html();
                    parentHtml = parentHtml.replaceFirst(Pattern.quote(matcher.group(0)),
                            spanHTML.toString());
                    ((Element) element).html(parentHtml);
                }
            }

            public void tail(Node arg0, int arg1) {
                // TODO Auto-generated method stub

            }
        });
        // }
    }

    /**
     * {@inheritDoc}
     */
    public void saveFile(String path) throws Exception {
        BufferedWriter htmlWriter = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(
                path), Constants.UTF8_ENCODING));
        htmlWriter.write(doc.toString());
        htmlWriter.close();
    }

}
