/**
 * Copyright (C) 2009  DAINIPPON SCREEN MFG. CO., LTD.  All Rights Reserved.
 *
 * N O T I C E
 * THIS MATERIAL IS CONSIDERED A TRADE SECRET BY DAINIPPON SCREEN.
 * UNAUTHORIZED ACCESS IS PROHIBITED.
 */


package com.gcs.cms.reader;

/**
 * Class Description
 ﾌ�*
 * @author GCS
 * @since EQUIOS 2.03
 */
public interface IFileReader {

    void readFile(String path) throws Exception;
    void parseFile() throws Exception;
    void saveFile(String path) throws Exception;
    
}
