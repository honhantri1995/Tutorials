/**
 * Copyright (C) 2009  DAINIPPON SCREEN MFG. CO., LTD.  All Rights Reserved.
 *
 * N O T I C E
 * THIS MATERIAL IS CONSIDERED A TRADE SECRET BY DAINIPPON SCREEN.
 * UNAUTHORIZED ACCESS IS PROHIBITED.
 */


package com.gcs.cms.utils;

import org.jsoup.nodes.Element;
import org.jsoup.parser.Tag;

import com.gcs.cms.constants.Constants;

/**
 * Class Description
 ́*
 * @author GCS Tung Nguyen Mar 16, 2018
 * @since EQUIOS 2.03
 */
public class HtmlUtils {

    public static Element generateSpanTagWithCSS(String cssAttrName, String value, String htmlText) {
        Element element = new Element(Tag.valueOf("span"), "");
        element.attr(Constants.ATTR_STYLE, cssAttrName + ":" + value + ";");
        element.html(htmlText);
        return element;
    }

    public static Element generateHTMLTag(String tagName, String htmlText) {
        Element element = new Element(Tag.valueOf(tagName), "");
        element.html(htmlText);
        return element;
    }
}
