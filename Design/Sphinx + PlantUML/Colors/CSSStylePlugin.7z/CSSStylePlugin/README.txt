About contents of this folder.

  
- CSSStylePlugin
  includes jar file and guideline to apply it.
  

- Source code folder: Source code of this plugin.
  We will update source to handle for exception cases if needed.


