Using CSS and HTML to style for SPHINX.
----------------------------------------
VERSION 2.0

This extension allows you to use css and html tag in SPHINX.

For example:
	
	Ex1. Fill the text with red color: 
		[color red] Hello world [/color] 
	=> This text will be conversed to CSS tag as following:
		<span style="color:red"> Hello world</span>  // The text in pdf will be filled with red color. 
	
	Ex2. Strike the text:
		[strike] Hello world [/strike]
	=> This text will be conversed to HTML tag as following:
		<strike> Hello world</strike> // The text will be striked.
	
	Some other samples:
		+ [float right] hello[\float] // this text will be float to right of document.
		+ [text-decoration underline] hello[\text-decoration] //Underline the text.
		+ [border solid 1px red] hello[\border] // Create a border for text.
		...

Configuration
	
	Insert the command line to makeSinglePDF.bat file before calling **wkhtmltopdf** as following:
		@echo off
		java -jar <path to CSSStylePlugin.jar> <path to html file which is created by sphinx>
		
	For the sample:
		File CSSStylePlugin.jar is put in root directory of Design.
		Add this line to makeSinglePDF.bat:
		
		@echo off
		java -jar .\CSSStylePlugin.jar .\_build\singlehtml\index.html
		